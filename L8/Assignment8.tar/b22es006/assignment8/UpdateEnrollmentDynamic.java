import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateEnrollmentDynamic {
    public static void updateEnrollmentDynamic(Connection conn) throws SQLException, IOException {
        String query = "INSERT INTO enrollment (ID, proj_id, team_id, season, year, completion_status) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(query);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 1; i <= 3; i++) {
            try {
                System.out.println("Enter ID:");
                int id = Integer.parseInt(reader.readLine());

                System.out.println("Enter Project ID:");
                int projId = Integer.parseInt(reader.readLine());

                System.out.println("Enter Team ID:");
                int teamId = Integer.parseInt(reader.readLine());

                System.out.println("Enter Season:");
                String season = reader.readLine();

                System.out.println("Enter Year (YYYY format):");
                int year = Integer.parseInt(reader.readLine());

                System.out.println("Enter Completion Status:");
                String status = reader.readLine();

                pstmt.setInt(1, id);
                pstmt.setInt(2, projId);
                pstmt.setInt(3, teamId);
                pstmt.setString(4, season);
                pstmt.setInt(5, year);
                pstmt.setString(6, status);
                pstmt.executeUpdate();
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter valid integer values for ID and Year.");
            }
        }

        System.out.println("Dynamic enrollment entries added.");
    }
}
