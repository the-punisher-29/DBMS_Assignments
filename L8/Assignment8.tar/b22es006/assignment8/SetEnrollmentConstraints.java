import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class SetEnrollmentConstraints {
    public static void setEnrollmentConstraints(Connection conn) throws SQLException {
        String alterQueryID = "ALTER TABLE enrollment MODIFY COLUMN ID INT";
        String alterQueryYear = "ALTER TABLE enrollment MODIFY COLUMN year YEAR";
        Statement stmt = conn.createStatement();
        stmt.executeUpdate(alterQueryID);
        stmt.executeUpdate(alterQueryYear);

        System.out.println("Constraints for enrollment table set.");
    }
}
