import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());
    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = JDBC_connec.getConnection();

            //in this main class,each of the 5 functions can be called to get the required result which is specific for a particular task in order 1 to 5---this is assignment7
            //EmployeeListQuery1.getList(conn);
            //System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
            //ProjectAssignmentsQuery2.getAssignment(conn);
            //System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
            //UpdateAffiliation.updateAffiliation(conn); //firstly i used this to create affiliation table then displayaffiliation is called to display the respective table
            //UpdateAffiliation.displayAffiliationTable(conn);
            //System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
            //VisitRND.getVisit(conn);
            //System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
            //UpdateInventory.updateInventory(conn);
            //System.out.println("----------------------------------------------------------------------------------------------------------------------------------");

            //Assignment 8

            // Update employee (static)
            //UpdateEmployee.updateemployee(conn);
            //System.out.println("----------------------------------------------------------------------------------------------------------------------------------");

            // Update employee (dynamic)
//            try {
//                UpdateEmployeeDynamic.updateemployeeDynamic(conn);
//            } catch (IOException e) {
//                System.out.println("Error reading input: " + e.getMessage());
//            }
              System.out.println("----------------------------------------------------------------------------------------------------------------------------------");

//            // Set constraints for enrollment table
              //SetEnrollmentConstraints.setEnrollmentConstraints(conn);
              //System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
//            // Update enrollment dynamically
//            try {
//                UpdateEnrollmentDynamic.updateEnrollmentDynamic(conn);
//            } catch (IOException e) {
//                System.err.println("Error: " + e.getMessage());
//                logger.log(Level.SEVERE, "SQL Exception occurred", e);
//            }
//            System.out.println("----------------------------------------------------------------------------------------------------------------------------------");

//            // Get employees with names starting from a specific letter
            //GetStudentsFromLetter.getStudentsFromLetter(conn, 'S');
//            System.out.println("----------------------------------------------------------------------------------------------------------------------------------");

//            // Delete projects
            DeleteProject.deleteproject(conn);
        }
        catch (SQLException e) {
            logger.log(Level.SEVERE, "SQL Exception occurred", e);
        }
        finally {
            // Close the connection
            JDBC_connec.closeConnection(conn);
        }
    }
}

