import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateEmployeeDynamic {
    public static void updateemployeeDynamic(Connection conn) throws SQLException, IOException {
        String query = "INSERT INTO employee (ID, emp_name, division_name, annual_salary) VALUES (?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(query);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 1; i <= 3; i++) {
            System.out.println("Enter ID:");
            int id = Integer.parseInt(reader.readLine());

            System.out.println("Enter Name:");
            String name = reader.readLine();

            System.out.println("Enter Division:");
            String division = reader.readLine();

            System.out.println("Enter Salary:");
            double salary = Double.parseDouble(reader.readLine());

            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, division);
            pstmt.setDouble(4, salary);
            pstmt.executeUpdate();
        }

        System.out.println("Dynamic employee entries added.");
    }
}
