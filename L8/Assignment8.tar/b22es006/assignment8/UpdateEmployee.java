import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateEmployee {
    public static void updateemployee(Connection conn) throws SQLException {
        String query = "INSERT INTO employee (ID, emp_name, division_name, annual_salary) VALUES (?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(query);

        // Static entries
        pstmt.setInt(1, 121);
        pstmt.setString(2, "John Doe");
        pstmt.setString(3, "Sales");
        pstmt.setDouble(4, 60000);
        pstmt.executeUpdate();

        pstmt.setInt(1, 122);
        pstmt.setString(2, "Jane Smith");
        pstmt.setString(3, "Marketing");
        pstmt.setDouble(4, 65000);
        pstmt.executeUpdate();

        System.out.println("Static employee entries added.");
    }
}
