import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetStudentsFromLetter {
    public static void getStudentsFromLetter(Connection conn, char letter) throws SQLException {
        String query = "SELECT * FROM employee WHERE emp_name LIKE ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, letter + "%");

        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("ID") + ", Name: " + rs.getString("emp_name") +
                    ", Division: " + rs.getString("division_name") + ", Salary: " + rs.getDouble("annual_salary"));
        }
    }
}
