import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//due to foreign key constraint ..first i have to delete those records in references table then from primary table;--just deleting from assignment table
public class DeleteProject {
    public static void deleteproject(Connection conn) throws SQLException {
        // Delete from assignment table where proj_id is referenced
        String deleteAssignmentQuery = "DELETE FROM assignment WHERE proj_id = ?";

        try (PreparedStatement deleteAssignmentStmt = conn.prepareStatement(deleteAssignmentQuery)) {
            // Replace with actual project IDs you want to delete
            deleteAssignmentStmt.setInt(1, 1003); // First project ID
            deleteAssignmentStmt.executeUpdate();
            deleteAssignmentStmt.setInt(1, 1013); // Second project ID
            deleteAssignmentStmt.executeUpdate();
        }

        System.out.println("Project records deleted from the assignment table.");
    }
}




