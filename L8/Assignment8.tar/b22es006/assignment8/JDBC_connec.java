
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBC_connec {
    //function for connecting to database
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/as6";
        String user = "root";
        String password = "sqlxsam@1929";
        return DriverManager.getConnection(url, user, password);
    }
    //function for closing the connection
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
                System.out.println("Connection closed.");
            } catch (SQLException e) {
                System.out.println("Failed to close the connection: " + e.getMessage());
            }
        }
    }
}
